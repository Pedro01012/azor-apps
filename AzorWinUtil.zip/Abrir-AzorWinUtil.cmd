@echo off
setlocal
cd /d "%~dp0"
if not exist "%~dp0azorwinutil.ps1" goto missing
echo Abrindo o Azor WinUtil. Confirme o aviso de administrador do Windows...
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0azorwinutil.ps1"
endlocal
exit /b 0

:missing
echo O arquivo azorwinutil.ps1 nao foi encontrado nesta pasta.
echo Extraia o ZIP inteiro antes de abrir.
pause
endlocal
exit /b 1
