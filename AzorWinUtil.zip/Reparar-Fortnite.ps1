<#
    Reparo Azor WinUtil - travamento de renderizacao em jogos (Fortnite)

    Devolve ao PADRAO DO WINDOWS apenas as chaves que podem travar a thread de renderizacao:
      1. Dwm\OverlayTestMode          (MPO desativado) -> removido, volta ao padrao
      2. Multimedia SystemResponsiveness 10 -> 20      (padrao)
      3. Tasks\Games\Scheduling Category High -> Medium (padrao)
      4. Win32PrioritySeparation 38 -> 2               (padrao)
      5. NetworkThrottlingIndex FFFFFFFF -> 10         (padrao)

    Nao mexe em nada mais: Game DVR, telemetria, servicos e apps ficam como estao.
    Precisa de administrador; se nao estiver, o script se reabre elevado.
#>

$ErrorActionPreference = 'Continue'

if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Host "Reabrindo como administrador..." -ForegroundColor Yellow
    Start-Process powershell.exe -Verb RunAs -ArgumentList "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", "`"$PSCommandPath`""
    return
}

$targets = @(
    [pscustomobject]@{ Path = 'HKLM:\SOFTWARE\Microsoft\Windows\Dwm'; Name = 'OverlayTestMode'; Action = 'Remove' }
    [pscustomobject]@{ Path = 'HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers'; Name = 'DisableOverlays'; Action = 'Remove' }
    [pscustomobject]@{ Path = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile'; Name = 'SystemResponsiveness'; Action = 'Set'; Value = 20; Type = 'DWord' }
    [pscustomobject]@{ Path = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile'; Name = 'NetworkThrottlingIndex'; Action = 'Set'; Value = 10; Type = 'DWord' }
    [pscustomobject]@{ Path = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games'; Name = 'Scheduling Category'; Action = 'Set'; Value = 'Medium'; Type = 'String' }
    [pscustomobject]@{ Path = 'HKLM:\SYSTEM\CurrentControlSet\Control\PriorityControl'; Name = 'Win32PrioritySeparation'; Action = 'Set'; Value = 2; Type = 'DWord' }
)

function Get-CurrentValue {
    param([string]$Path, [string]$Name)
    try { return [string](Get-ItemProperty -LiteralPath $Path -Name $Name -ErrorAction Stop).$Name }
    catch { return '(ausente)' }
}

Write-Host ""
Write-Host "=== ANTES ===" -ForegroundColor Cyan
foreach ($t in $targets) { Write-Host ("  {0}\{1} = {2}" -f $t.Path, $t.Name, (Get-CurrentValue $t.Path $t.Name)) }

Write-Host ""
Write-Host "=== APLICANDO ===" -ForegroundColor Cyan
foreach ($t in $targets) {
    try {
        if ($t.Action -eq 'Remove') {
            if ((Get-CurrentValue $t.Path $t.Name) -ne '(ausente)') {
                Remove-ItemProperty -LiteralPath $t.Path -Name $t.Name -Force -ErrorAction Stop
                Write-Host ("  removido: {0}\{1}" -f $t.Path, $t.Name) -ForegroundColor Green
            } else {
                Write-Host ("  ja estava ausente: {0}\{1}" -f $t.Path, $t.Name)
            }
        } else {
            if (-not (Test-Path -LiteralPath $t.Path)) { New-Item -Path $t.Path -Force | Out-Null }
            New-ItemProperty -LiteralPath $t.Path -Name $t.Name -Value $t.Value -PropertyType $t.Type -Force | Out-Null
            Write-Host ("  definido: {0}\{1} = {2}" -f $t.Path, $t.Name, $t.Value) -ForegroundColor Green
        }
    } catch {
        Write-Host ("  FALHOU: {0}\{1} -> {2}" -f $t.Path, $t.Name, $_.Exception.Message) -ForegroundColor Red
    }
}

Write-Host ""
Write-Host "=== DEPOIS ===" -ForegroundColor Cyan
foreach ($t in $targets) { Write-Host ("  {0}\{1} = {2}" -f $t.Path, $t.Name, (Get-CurrentValue $t.Path $t.Name)) }

$gameBar = Get-AppxPackage -Name 'Microsoft.XboxGamingOverlay' -ErrorAction SilentlyContinue
Write-Host ""
Write-Host "=== AVISO ms-gamingoverlay ===" -ForegroundColor Cyan
if ($gameBar) {
    Write-Host "  Xbox Game Bar instalada: o aviso nao deve mais aparecer."
} else {
    Write-Host "  Xbox Game Bar NAO esta instalada - e por isso que aparece o aviso ms-gamingoverlay."
    Write-Host "  Para resolver, instale de volta na Microsoft Store (Xbox Game Bar)."
    Write-Host "  Abrindo a pagina da Store..."
    Start-Process "ms-windows-store://pdp/?productid=9NZKPSTSNW4P" -ErrorAction SilentlyContinue
}

Write-Host ""
Write-Host "PROXIMO PASSO: reinicie o PC e teste o Fortnite." -ForegroundColor Yellow
Write-Host "Se ainda travar, no Fortnite mude o modo de exibicao para 'Tela cheia em janela' e teste de novo." -ForegroundColor Yellow
Write-Host ""
Read-Host "Pressione Enter para fechar"
