@echo off
setlocal
cd /d "%~dp0"
echo Reparo do travamento de renderizacao (Fortnite). Confirme o aviso de administrador...
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Reparar-Fortnite.ps1"
endlocal
